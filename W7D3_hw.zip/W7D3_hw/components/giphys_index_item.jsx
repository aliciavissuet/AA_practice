import React from 'react'

const GiphyIndexItem = (props) => {
    return (
        <img src={props.giphy}/>
    );
}
export default GiphyIndexItem;