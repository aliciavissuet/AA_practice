import React from 'react';
import Calculator from './calculator';

const Congrats = () => (<Calculator/>);

export default Congrats;
