require 'test_helper'

class CorgiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
